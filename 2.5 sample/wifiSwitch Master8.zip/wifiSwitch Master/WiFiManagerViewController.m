//
//  WiFiManagerViewController.m
//  wifiSwitch
//
//  Created by David Lee on 29/03/2017.
//  Copyright © 2017 Jons N Lee Pty Ltd. All rights reserved.
//

#import "WiFiManagerViewController.h"

@interface WiFiManagerViewController ()
@property (weak, nonatomic) IBOutlet UILabel *lblSID;
@property (weak, nonatomic) IBOutlet UILabel *lblPWD;
@property (weak, nonatomic) IBOutlet UILabel *lblOPN;
@property (weak, nonatomic) IBOutlet UILabel *lblNPN;
@property (weak, nonatomic) IBOutlet UILabel *lblIPA;

@property (weak, nonatomic) IBOutlet UITextField *txtSID;
@property (weak, nonatomic) IBOutlet UITextField *txtPWD;
@property (weak, nonatomic) IBOutlet UITextField *txtOPN;
@property (weak, nonatomic) IBOutlet UITextField *txtNPN;
@property (weak, nonatomic) IBOutlet UITextField *txtIPA;
@property (weak, nonatomic) IBOutlet UITextView *txtViewLog;

@property (weak, nonatomic) IBOutlet UISegmentedControl *segControl;
@property (weak, nonatomic) IBOutlet UIButton *btnSend;

@property (strong,nonatomic) BTLECentralViewController *defaultBLEController;

@end


@implementation WiFiManagerViewController


-(id)init{
    self = [super init];
    if(self){
        //...your initialization code
        [[BTLECentralViewController  sharedClass] addDelegate:self];
    }
    return self;
}


-(void) dealloc{
    [[BTLECentralViewController sharedClass] removeDelegate:self];
  //  [super dealloc];
}


- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    if( !((textField.tag == 101) || (textField.tag == 102)) )
        return YES;
    
    if(string.length == 0)
        return YES;
    
    if(textField.text.length == 4)
        return NO;
    
    NSCharacterSet *nonNumberSet = [[NSCharacterSet decimalDigitCharacterSet] invertedSet];
    
    if ([string rangeOfCharacterFromSet:nonNumberSet].location != NSNotFound)
    {
        return NO;
    }
    return YES;
}

-(void) TextLoging:(NSString *) stringLog
{
    if( stringLog != nil ) {
        
        _txtViewLog.text = [_txtViewLog.text stringByAppendingString:stringLog];
        
        NSRange txtOutputRange;
        txtOutputRange.location = _txtViewLog.text.length;
        txtOutputRange.length = 0;
        _txtViewLog.editable = YES;
        [_txtViewLog scrollRangeToVisible:txtOutputRange];
        [_txtViewLog setSelectedRange:txtOutputRange];
        _txtViewLog.editable = NO;
    }
}


- (IBAction)tapTaging:(id)sender {
    
    [[UIApplication sharedApplication] sendAction:@selector(resignFirstResponder) to:nil from:nil forEvent:nil];
    [self KeyboardDisappear:FALSE];

}

-(void)KeyboardDisappear:(BOOL)isUP
{
    NSTimeInterval animationDuration = 0.30f;
    [UIView beginAnimations:@"ResizeForKeyBoard" context:nil];
    [UIView setAnimationDuration:animationDuration];
    float width = self.view.frame.size.width;
    float height = self.view.frame.size.height;
    CGRect rect;
    if(isUP){
        rect = CGRectMake(0.0f, -116,width,height);
    }else{
        rect = CGRectMake(0.0f, 0,width,height);
        
    }
    self.view.frame = rect;
    [UIView commitAnimations];
}


- (IBAction)btnSendData:(UIButton *)sender {
    
    
    
    [[UIApplication sharedApplication] sendAction:@selector(resignFirstResponder) to:nil from:nil forEvent:nil];
    [self KeyboardDisappear:FALSE];
    
    if( _segControl.selectedSegmentIndex == 0 ) {
        
        NSString *tmpString =  [NSString stringWithFormat:@"@GET\t%@\n", _txtOPN.text];
    
        //pvMinute.selectedR
        NSLog(@"CMD:%@", tmpString);
        
        [ _defaultBLEController SendData:tmpString ];
        
       
    }
    
    if( _segControl.selectedSegmentIndex == 1 ) {
        
        if( [_txtSID.text  isEqual: @"RST"] ) {
            NSString *tmpString =  [NSString stringWithFormat:@"@RST\t%@\n", _txtOPN.text];
            
            //pvMinute.selectedR
            NSLog(@"CMD:%@", tmpString);
            
            [ _defaultBLEController SendData:tmpString ];

        }
        
        else {
            
            NSTimeZone *timeZone = [NSTimeZone localTimeZone];
            NSString *tzName = [timeZone abbreviation];
            // NSString  *tzAll[] = [timeZone  abbreviationDictionary ];
            
            //NSString *tzName = @"AEST"; //AEDT
            
            NSString *tmpString =  [NSString stringWithFormat:@"@PUT\t%@\t%@\t%@\t%@\t%@\n", _txtOPN.text, _txtSID.text, _txtPWD.text, _txtNPN.text, tzName];
            
            //pvMinute.selectedR
            NSLog(@"CMD:%@", tmpString);
            
            [ _defaultBLEController SendData:tmpString ];

        }
        
    }
    
    //[_aivWaiting stopAnimating ];
    
    
}


- (IBAction)segControlData:(id)sender {
    
    if ([sender isEqual:self.segControl]){
        
        //get index position for the selected control
        NSInteger selectedIndex = [sender selectedSegmentIndex];
        
        if( selectedIndex == 0 ) {
            //get the Text for the segmented control that was selected
            _txtSID.enabled = false;
            _txtPWD.enabled = false;
            _txtIPA.enabled = false;
            _txtNPN.enabled = false;
            _txtSID.text = @"";
            _txtPWD.text = @"";
            _txtIPA.text = @"";
            _txtNPN.text = @"";
        } else {
            _txtSID.enabled = true;
            _txtPWD.enabled = true;
            _txtIPA.enabled = false;
            _txtNPN.enabled = true;
        }
    }
    
}



- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    NSLog(@"WIFI viewLoad");
    
    // _myTable.autoresizingMask = UIViewAutoresizingNone;
    
   
    // Initialize Data
    _txtSID.enabled = false;
    _txtPWD.enabled = false;
    _txtIPA.enabled = false;
    _txtNPN.enabled = false;
    
    _txtOPN.returnKeyType = UIReturnKeyDone;
    _txtOPN.delegate = self;
    
    _txtNPN.returnKeyType = UIReturnKeyDone;
    _txtNPN.delegate = self;

    //[_txSID resignFirstResponder];
    //[self.view endEditing:YES];
    
    
    self.defaultBLEController = [BTLECentralViewController defaultBLEController:_txtViewLog];
    //self.defaultBLEController.delegate = (id)self;
    
    [[BTLECentralViewController  sharedClass] addDelegate:(id) self];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/


- (void) didReadvalue : (NSString *) stringFromData
{

    
   // Log it
    NSLog(@"WIFI Received: %@", stringFromData);
    
    if( stringFromData == nil ) return;
    
        
    
    //[self TextLoging:stringFromData];
    
    static NSString *strSplit1 = @"", *strSplit2 = @"";
    
    NSArray* components = [stringFromData componentsSeparatedByString:@"\n"];
    
    //components
    NSUInteger size = [components count];
    //NSLog(@"word count: %d , length = %d", size, [[components objectAtIndex:0] length] );
    if( size  == 1 ) {
        if( [ strSplit2 length] > 0 ) {
            //NSLog(@"Split1: %@%@", strSplit1, strSplit2);
            strSplit1 = [strSplit2 stringByAppendingString: [components objectAtIndex:0] ];
            //NSLog(@"Split2: %@%@", strSplit1, strSplit2);
            strSplit2 = @"";
        }
        else {
            strSplit1 = [strSplit1 stringByAppendingString: [components objectAtIndex:0] ];
            //NSLog(@"Split3: %@%@", strSplit1, strSplit2);
        }
        //_txSID.text = strSplit1;
        //strSplit1 = @"";
    }
    if( size == 2 ) {
        if( [ strSplit1 length] > 0 ) {
            //NSLog(@"Split4: %@%@", strSplit1, strSplit2);
            strSplit1 = [strSplit1 stringByAppendingString: [components objectAtIndex:0] ];
            //NSLog(@"Split5: %@%@", strSplit1, strSplit2);
            strSplit2 = @"";
        } else {
            strSplit1 = [strSplit1 stringByAppendingString:  [components objectAtIndex:0] ];
            strSplit2 = [components objectAtIndex:1];
            //NSLog(@"Split6: %@%@", strSplit1, strSplit2);
        }
        
        
        NSArray* words = [strSplit1 componentsSeparatedByString:@"\t"];
        
        NSString* body0 = [words objectAtIndex:0];
        
        if( [body0 isEqual:@"ANS"] ) {
            
            //NSUInteger size1 = [component count];
            
            //if( size1 == 3 ) {
            NSString* body1 = [words objectAtIndex:1];
            NSString* body2 = [words objectAtIndex:2];
            NSString* body3 = [words objectAtIndex:3];
            //}
            
                     _txtIPA.text = body1;
                     _txtSID.text = body2;
                     _txtPWD.text = body3;
            
        }
        if( [body0 isEqual:@"MSG"] ) {
            NSString* body1 = [[words objectAtIndex:1] stringByAppendingString: @"\n" ];
            [self TextLoging:body1];
        }
        
        strSplit1 =@"";
    }
 
}


@end
