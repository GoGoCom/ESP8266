//
//  LogViewController.h
//  DarkBlue
//
//  Created by chenee on 14-3-26.
//  Copyright (c) 2014年 chenee. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LogViewController : UIViewController

@end
