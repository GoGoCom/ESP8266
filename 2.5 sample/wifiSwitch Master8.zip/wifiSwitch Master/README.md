仿照LightBlue的central模式实现全部功能，升级logger机制，可以在线查看BT log状态(直接使用NSLog())。
并且可以随时mail当前log给需要的人。希望这个框架可以方便您的蓝牙的开发和调试。

LightBlue(https://itunes.apple.com/cn/app/lightblue-bluetooth-low-energy/id557428110?mt=8
) like Bluetooth LE demo ,with full function of central mode.

improve the debug logger ,you can lookup the log at run time without connect to Xcode
you even could send the logger direct to other developer with email(e.g tester send log to developer),
by your iphone.it's pretty cool.  wish it could help you for your BT LE development.

BTW:
logger howto ,please refer to :http://code4app.com/ios/524b9f5b6803faf178000000
or refer the "F**King Source Code :)"

the last and most important thing is : I'm still working on it ,so feel free to touch me
chenee543216@gmail.com



