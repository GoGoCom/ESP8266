WS2812
======
Breakout Board for the WS2812 RGB chip

WS2812 Datasheet: http://www.adafruit.com/datasheets/WS2812.pdf

WS2812.lib : A eagle library for the new WS2812B RGB LED chip
