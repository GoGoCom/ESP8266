//
//  MQTTManagerViewController.m
//  wifiSwitch
//
//  Created by David Lee on 29/03/2017.
//  Copyright © 2017 Jons N Lee Pty Ltd. All rights reserved.
//

#import "MQTTManagerViewController.h"
#import "RadioButton.h"

@interface MQTTManagerViewController ()
@property (weak, nonatomic) IBOutlet UILabel *lblServer;
@property (weak, nonatomic) IBOutlet UILabel *lblPort;
@property (weak, nonatomic) IBOutlet UILabel *lblUserID;
@property (weak, nonatomic) IBOutlet UILabel *lblPassword;
@property (weak, nonatomic) IBOutlet UILabel *lblTopic;
@property (weak, nonatomic) IBOutlet UILabel *lblQoS;
@property (weak, nonatomic) IBOutlet UILabel *lblRetain;
@property (weak, nonatomic) IBOutlet UILabel *lblMessage;

@property (weak, nonatomic) IBOutlet UITextField *txtServer;
@property (weak, nonatomic) IBOutlet UITextField *txtPort;
@property (weak, nonatomic) IBOutlet UITextField *txtUserID;
@property (weak, nonatomic) IBOutlet UITextField *txtPassword;
@property (weak, nonatomic) IBOutlet UITextField *txtTopic;

@property (weak, nonatomic) IBOutlet UITextField *txtQoS;

@property (weak, nonatomic) IBOutlet UISwitch *swtRetain;


@property (weak, nonatomic) IBOutlet UITextField *txtMessage;

@property (weak, nonatomic) IBOutlet RadioButton *radio1;
@property (weak, nonatomic) IBOutlet RadioButton *radio2;

@property (weak, nonatomic) IBOutlet UIButton *btnRecv;

@property (weak, nonatomic) IBOutlet UIButton *btnSend;

@property (strong,nonatomic) BTLECentralViewController *defaultBLEController;

@end

@implementation MQTTManagerViewController


-(id)init{
    self = [super init];
    if(self){
        //...your initialization code
        [[BTLECentralViewController  sharedClass] addDelegate:self];
    }
    return self;
}

- (IBAction)onRadioBtn:(RadioButton *)sender {
    _txtQoS.text = [NSString stringWithFormat:@"Selected: %@", sender.titleLabel.text];
    
}

-(void) dealloc{
    [[BTLECentralViewController sharedClass] removeDelegate:self];
    //  [super dealloc];
}



//static BTLECentralViewController * _defaultBLEController = nil;
- (IBAction)btnRecvData:(UIButton *)sender {
    
    NSString *tmpString =  [NSString stringWithFormat:@"@LET\t%@\n", @"0000"];
    
    //pvMinute.selectedR
    NSLog(@"CMD:%@", tmpString);
    
    [ _defaultBLEController SendData:tmpString ];

}

- (IBAction)btnSendData:(UIButton *)sender {
    
    [[UIApplication sharedApplication] sendAction:@selector(resignFirstResponder) to:nil from:nil forEvent:nil];
    [self KeyboardDisappear:FALSE];
    
    
        NSString *tmpString =  [NSString stringWithFormat:@"@SET\t%@\t%@\t%@\t%@\t%@\t%@\t%@\t%hhd\t%@\n", @"0000", _txtServer.text, _txtPort.text, _txtUserID.text, _txtPassword.text, _txtTopic.text, _txtQoS.text, _swtRetain.isOn, _txtMessage.text];
    
        //pvMinute.selectedR
        NSLog(@"CMD:%@", tmpString);
        
        [ _defaultBLEController SendData:tmpString ];
    
    
    
    //[_aivWaiting stopAnimating ];
    
    
    //[self.defaultBTServer.selectPeripheral readValueForCharacteristic:self.defaultBTServer.selectCharacteristic ];
    
}

- (IBAction)tapTaging:(id)sender {
    [[UIApplication sharedApplication] sendAction:@selector(resignFirstResponder) to:nil from:nil forEvent:nil];
    [self KeyboardDisappear:FALSE];
    
}

-(void)KeyboardDisappear:(BOOL)isUP
{
    NSTimeInterval animationDuration = 0.30f;
    [UIView beginAnimations:@"ResizeForKeyBoard" context:nil];
    [UIView setAnimationDuration:animationDuration];
    float width = self.view.frame.size.width;
    float height = self.view.frame.size.height;
    CGRect rect;
    if(isUP){
        rect = CGRectMake(0.0f, -116,width,height);
    }else{
        rect = CGRectMake(0.0f, 0,width,height);
        
    }
    self.view.frame = rect;
    [UIView commitAnimations];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    //_radio1.groupButtons = @[_radio1, _radio2];
    [_radio1 setGroupButtons:@[_radio1, _radio2] ];
    
    NSLog(@"MQTT viewLoad");
    
    self.defaultBLEController = [BTLECentralViewController defaultBLEController:nil];
    //self.defaultBLEController.delegate = (id)self;
    
    [[BTLECentralViewController  sharedClass] addDelegate:(id) self];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/


- (void) didReadvalue:(NSString *)stringFromData
{

    
    
    // Otherwise, just add the data on to what we already have
    //[self.data appendData:characteristic.value];
    
    // Log it
   NSLog(@"MQTT Received: %@", stringFromData);
    
   if( stringFromData == nil ) return;
    
    //[self TextLoging:stringFromData];
    
    static NSString *strSplit1 = @"", *strSplit2 = @"";
    
    NSArray* components = [stringFromData componentsSeparatedByString:@"\n"];
    
    //components
    NSUInteger size = [components count];
    //NSLog(@"word count: %d , length = %d", size, [[components objectAtIndex:0] length] );
    if( size  == 1 ) {
        if( [ strSplit2 length] > 0 ) {
            //NSLog(@"Split1: %@%@", strSplit1, strSplit2);
            strSplit1 = [strSplit2 stringByAppendingString: [components objectAtIndex:0] ];
            //NSLog(@"Split2: %@%@", strSplit1, strSplit2);
            strSplit2 = @"";
        }
        else {
            strSplit1 = [strSplit1 stringByAppendingString: [components objectAtIndex:0] ];
            //NSLog(@"Split3: %@%@", strSplit1, strSplit2);
        }
        //_txSID.text = strSplit1;
        //strSplit1 = @"";
    }
    if( size == 2 ) {
        if( [ strSplit1 length] > 0 ) {
            //NSLog(@"Split4: %@%@", strSplit1, strSplit2);
            strSplit1 = [strSplit1 stringByAppendingString: [components objectAtIndex:0] ];
            //NSLog(@"Split5: %@%@", strSplit1, strSplit2);
            strSplit2 = @"";
        } else {
            strSplit1 = [strSplit1 stringByAppendingString:  [components objectAtIndex:0] ];
            strSplit2 = [components objectAtIndex:1];
            //NSLog(@"Split6: %@%@", strSplit1, strSplit2);
        }
        
        
        NSArray* words = [strSplit1 componentsSeparatedByString:@"\t"];
        
        NSString* body0 = [words objectAtIndex:0];
        
        if( [body0 isEqual:@"ENQ"] ) {
            
            //NSUInteger size1 = [component count];
            
            NSString* body1 = [words objectAtIndex:1];
            NSString* body2 = [words objectAtIndex:2];
            NSString* body3 = [words objectAtIndex:3];
            NSString* body4 = [words objectAtIndex:4];
            NSString* body5 = [words objectAtIndex:5];
            NSString* body6 = [words objectAtIndex:6];
            NSString* body7 = [words objectAtIndex:7];
            NSString* body8 = [words objectAtIndex:8];
            
            
            _txtServer.text   = body1 ;
            _txtPort.text     = body2 ;
            _txtUserID.text   = body3 ;
            _txtPassword.text = body4 ;
            _txtTopic.text    = body5 ;
            _txtQoS.text      = body6 ;
            if( [body7 isEqualToString:@"1"] ) {
                [_swtRetain setOn:true] ;
            } else {
                [_swtRetain setOn:false] ;
            }
            _txtMessage.text  = body8 ;            

            
        }

        
        strSplit1 =@"";
    }
}

    
@end
