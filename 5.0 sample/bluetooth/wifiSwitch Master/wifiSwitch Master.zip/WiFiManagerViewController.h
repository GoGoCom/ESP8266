//
//  WiFiManagerViewController.h
//  wifiSwitch
//
//  Created by David Lee on 29/03/2017.
//  Copyright © 2017 Jons N Lee Pty Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BTLECentralViewController.h"

@interface WiFiManagerViewController : UIViewController < BTLECentralViewControllerDelegate, UITextFieldDelegate, UIPickerViewDelegate, UIPickerViewDataSource >

@end
