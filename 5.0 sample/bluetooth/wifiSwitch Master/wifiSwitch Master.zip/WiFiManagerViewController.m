//
//  WiFiManagerViewController.m
//  wifiSwitch
//
//  Created by David Lee on 29/03/2017.
//  Copyright © 2017 Jons N Lee Pty Ltd. All rights reserved.
//

#import "WiFiManagerViewController.h"

@interface WiFiManagerViewController ()
@property (weak, nonatomic) IBOutlet UILabel *lblDeviceID;
@property (weak, nonatomic) IBOutlet UILabel *lblSID;
@property (weak, nonatomic) IBOutlet UILabel *lblPWD;
@property (weak, nonatomic) IBOutlet UILabel *lblOPN;
@property (weak, nonatomic) IBOutlet UILabel *lblNPN;
@property (weak, nonatomic) IBOutlet UILabel *lblIPA;
@property (weak, nonatomic) IBOutlet UILabel *lblLocalName;
@property (weak, nonatomic) IBOutlet UILabel *lblHostName;

@property (weak, nonatomic) IBOutlet UITextField *txtSID;
@property (weak, nonatomic) IBOutlet UITextField *txtPWD;
@property (weak, nonatomic) IBOutlet UITextField *txtIPA;
@property (weak, nonatomic) IBOutlet UITextField *txtLocalName;
@property (weak, nonatomic) IBOutlet UITextField *txtHostName;

@property (weak, nonatomic) IBOutlet UIPickerView *pickTimeDiff;

@property (weak, nonatomic) IBOutlet UITextView *txtViewLog;

@property (weak, nonatomic) IBOutlet UISegmentedControl *segControl;
@property (weak, nonatomic) IBOutlet UIButton *btnSend;

@property (strong,nonatomic) BTLECentralViewController *defaultBLEController;

@end

NSInteger SpinHourRow, SpinMinRow;
NSArray *SpinMinuteData;


@implementation WiFiManagerViewController




-(id)init{
    self = [super init];
    if(self){
        //...your initialization code
        [[BTLECentralViewController  sharedClass] addDelegate:self];
    }
    return self;
}


-(void) dealloc{
    [[BTLECentralViewController sharedClass] removeDelegate:self];
  //  [super dealloc];
}


-(void) TextLoging:(NSString *) stringLog
{
    if( stringLog != nil ) {
        
        _txtViewLog.text = [_txtViewLog.text stringByAppendingString:stringLog];
        
        NSRange txtOutputRange;
        txtOutputRange.location = _txtViewLog.text.length;
        txtOutputRange.length = 0;
        _txtViewLog.editable = YES;
        [_txtViewLog scrollRangeToVisible:txtOutputRange];
        [_txtViewLog setSelectedRange:txtOutputRange];
        _txtViewLog.editable = NO;
    }
}


- (IBAction)tapTaging:(id)sender {
    
    [[UIApplication sharedApplication] sendAction:@selector(resignFirstResponder) to:nil from:nil forEvent:nil];
    [self KeyboardDisappear:FALSE];

}

-(void)KeyboardDisappear:(BOOL)isUP
{
    NSTimeInterval animationDuration = 0.30f;
    [UIView beginAnimations:@"ResizeForKeyBoard" context:nil];
    [UIView setAnimationDuration:animationDuration];
    float width = self.view.frame.size.width;
    float height = self.view.frame.size.height;
    CGRect rect;
    if(isUP){
        rect = CGRectMake(0.0f, -116,width,height);
    }else{
        rect = CGRectMake(0.0f, 0,width,height);
        
    }
    self.view.frame = rect;
    [UIView commitAnimations];
}


- (IBAction)btnSendData:(UIButton *)sender {
    
    /*
    NSString* chkID = _lblDeviceID.text;

    
    if( ( [chkID length] == 0 ) || (![ [chkID substringWithRange:NSMakeRange(0, 3)] isEqualToString:@"JNL" ] ) ) {
    
         UIAlertView *theAlert = [[UIAlertView alloc] initWithTitle:@"Notice"
                                                            message:@"Wrong Device ID "
                                                           delegate:self
                                                  cancelButtonTitle:@"OK"
                                                  otherButtonTitles:nil];
            [theAlert show];
            return;
    }*/

    

    [[UIApplication sharedApplication] sendAction:@selector(resignFirstResponder) to:nil from:nil forEvent:nil];
    [self KeyboardDisappear:FALSE];
    
    if( _segControl.selectedSegmentIndex == 0 ) {
        
        NSString *tmpString =  [NSString stringWithFormat:@"@GET\t%@\n", @"0000"];
    
        //pvMinute.selectedR
        NSLog(@"CMD:%@", tmpString);
        
        [ _defaultBLEController SendData:tmpString ];
       
    }
    
    if( _segControl.selectedSegmentIndex == 1 ) {
        
        if( [_txtSID.text  isEqual: @"RST"] ) {
            NSString *tmpString =  [NSString stringWithFormat:@"@RST\t%@\n", @"0000"];
            
            //pvMinute.selectedR
            NSLog(@"CMD:%@", tmpString);
            
            [ _defaultBLEController SendData:tmpString ];

        }
        
        else {
            
            /*
            NSTimeZone *timeZone = [NSTimeZone localTimeZone];
            NSString *tzName = [timeZone abbreviation];
            // NSString  *tzAll[] = [timeZone  abbreviationDictionary ];
            
            //NSString *tzName = @"AEST"; //AEDT
            if( [_txtNPN.text isEqual:@""] ) {
                UIAlertView *theAlert = [[UIAlertView alloc] initWithTitle:@"Notice"
                                                                   message:@"4 Digit number for PIN pls!"
                                                                  delegate:self
                                                         cancelButtonTitle:@"OK"
                                                         otherButtonTitles:nil];
                [theAlert show];
                return;
            }
            */
            
            NSString *tmpString =  [NSString stringWithFormat:@"@PUT\t%@\t%@\t%@\t%@\t%ld\t%ld\t%@\t%@\n", @"0000", _txtSID.text, _txtPWD.text, @"0000", (long) SpinHourRow, (long) SpinMinRow, _txtLocalName.text, _txtHostName.text];
            
            //pvMinute.selectedR
            NSLog(@"CMD:%@", tmpString);
            
            [ _defaultBLEController SendData:tmpString ];

        }
        
    }
    
    //[_aivWaiting stopAnimating ];
    
    
}


- (IBAction)segControlData:(id)sender {
    
    if ([sender isEqual:self.segControl]){
        
        //get index position for the selected control
        NSInteger selectedIndex = [sender selectedSegmentIndex];
        
        if( selectedIndex == 0 ) {
            //get the Text for the segmented control that was selected
            _txtSID.enabled = false;
            _txtPWD.enabled = false;
            _txtIPA.enabled = false;
            _txtLocalName.enabled = false;
            _txtHostName.enabled = false;
            _txtSID.text = @"";
            _txtPWD.text = @"";
            _txtIPA.text = @"";
            _txtLocalName.text = @"";
            _txtHostName.text = @"";
        } else {
            _txtSID.enabled = true;
            _txtPWD.enabled = true;
            _txtIPA.enabled = false;
            _txtLocalName.enabled = true;
            _txtHostName.enabled = true;
        }
    }
    
}



- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    NSLog(@"WIFI viewLoad");
    
    // _myTable.autoresizingMask = UIViewAutoresizingNone;
    

    SpinMinuteData = @[
                        @[@"-12", @"-11", @"-10", @"-09", @"-08", @"-07", @"-06", @"-05", @"-04", @"-03", @"-02", @"-01", @" 0 ", @"+01", @"+02", @"+03", @"+04", @"+05", @"+06", @"+07", @"+08", @"+09", @"+10", @"+11", @"+12"],
                        @[@"00", @"15", @"30", @"45" ]
                      ];

    self.pickTimeDiff.dataSource = self;
    self.pickTimeDiff.delegate = self;
    
  
    // Initialize Data
    _txtSID.enabled = false;
    _txtPWD.enabled = false;
    _txtIPA.enabled = false;
    _txtLocalName.enabled = false;
    _txtHostName.enabled = false;
    
    SpinHourRow = 12;
    SpinMinRow  = 0;
    
    [_pickTimeDiff selectRow:SpinHourRow inComponent:0 animated:false];
    [_pickTimeDiff selectRow:SpinMinRow inComponent:1  animated:false];
    
    //[_txSID resignFirstResponder];
    //[self.view endEditing:YES];
    
    
    self.defaultBLEController = [BTLECentralViewController defaultBLEController:_txtViewLog];
    //self.defaultBLEController.delegate = (id)self;
    
    [[BTLECentralViewController  sharedClass] addDelegate:(id) self];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{
    if( component == 0 ) return 25;
    
    return 4;
    //{
    
    
    //_pickerData1[component]. .count;
    //}
    /*
     if( [pickerView  isEqual: _TimeSpin ] ) {
     return _pickerData1.count;
     }
     if( [pickerView  isEqual: _SpeedSpin ] ) {
     return _pickerData2.count;
     } */
    
    
    
}

- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
    //if( pickerView.tag == 0 )
    //{
    return 2; //SpinMinuteData.count;
    //}
    /*
     if( [pickerView  isEqual: _TimeSpin ] ) {
     return 4;
     }
     if( [pickerView  isEqual: _SpeedSpin ] ) {
     return 4;
     } */
    
}



- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component
{
    //if( [pickerView  isEqual: _TimeSpin ] ) {
    
    //NSLog( @"%d, %d, %@" ,row, component, _pickerData1[component][row]);
    
    //}
    //    _SpinColumn = component;
    //    _SpinRow = row;
    //_textview.text = [NSString stringWithFormat: @"%d, %d, %@" ,row, component, _pickerData1[component][row] ];    //if( pickerView.tag == 0 )
    //{
    return SpinMinuteData[component][row]; //[ NSString stringWithFormat: @"%d", component ];
    //}
    /*
     if( [pickerView  isEqual: _TimeSpin ] ) {
     return _pickerData1[component][row];
     }
     if( [pickerView  isEqual: _SpeedSpin ] ) {
     return _pickerData2[component][row];
     }*/
    
    //return NULL;
}

- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component
{
    //   _textview.text = _pickerData1[component][row];
    if( component == 0 ) SpinHourRow = row;
    if( component == 1 ) SpinMinRow = row;

    /*
     if( [pickerView  isEqual: _TimeSpin ] ) {
     _textview.text = _pickerData1[component][row];
     }
     if( [pickerView  isEqual: _SpeedSpin ] ) {
     _textview.text =  _pickerData2[component][row];
     } */
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/


- (void) didReadvalue : (NSString *) stringFromData
{

    
   // Log it
    NSLog(@"WIFI Received: %@", stringFromData);
    
    if( stringFromData == nil ) return;
    
        
    
    //[self TextLoging:stringFromData];
    
    static NSString *strSplit1 = @"", *strSplit2 = @"";
    
    NSArray* components = [stringFromData componentsSeparatedByString:@"\n"];
    
    //components
    NSUInteger size = [components count];
    //NSLog(@"word count: %d , length = %d", size, [[components objectAtIndex:0] length] );
    if( size  == 1 ) {
        if( [ strSplit2 length] > 0 ) {
            //NSLog(@"Split1: %@%@", strSplit1, strSplit2);
            strSplit1 = [strSplit2 stringByAppendingString: [components objectAtIndex:0] ];
            //NSLog(@"Split2: %@%@", strSplit1, strSplit2);
            strSplit2 = @"";
        }
        else {
            strSplit1 = [strSplit1 stringByAppendingString: [components objectAtIndex:0] ];
            //NSLog(@"Split3: %@%@", strSplit1, strSplit2);
        }
        //_txSID.text = strSplit1;
        //strSplit1 = @"";
    }
    if( size == 2 ) {
        if( [ strSplit1 length] > 0 ) {
            //NSLog(@"Split4: %@%@", strSplit1, strSplit2);
            strSplit1 = [strSplit1 stringByAppendingString: [components objectAtIndex:0] ];
            //NSLog(@"Split5: %@%@", strSplit1, strSplit2);
            strSplit2 = @"";
        } else {
            strSplit1 = [strSplit1 stringByAppendingString:  [components objectAtIndex:0] ];
            strSplit2 = [components objectAtIndex:1];
            //NSLog(@"Split6: %@%@", strSplit1, strSplit2);
        }
        
        
        NSArray* words = [strSplit1 componentsSeparatedByString:@"\t"];
        
        NSString* body0 = [words objectAtIndex:0];
        
        if( [body0 isEqual:@"ANS"] ) {
            
            //NSUInteger size1 = [component count];
            
            //if( size1 == 3 ) {
            NSString* body1 = [words objectAtIndex:1];
            NSString* body2 = [words objectAtIndex:2];
            NSString* body3 = [words objectAtIndex:3];
            NSString* body4 = [words objectAtIndex:4];
            NSString* body5 = [words objectAtIndex:5];
            NSString* body6 = [words objectAtIndex:6];
            NSString* body7 = [words objectAtIndex:7];
            //}
            
                     _txtIPA.text = body1;
                     _txtSID.text = body2;
                     _txtPWD.text = body3;
                     SpinHourRow  = body4.integerValue;
                       SpinMinRow = body5.integerValue;
               _txtLocalName.text = body6;
                _txtHostName.text = [body7 substringWithRange:NSMakeRange(0, [body7 rangeOfString:@"\r"].location )];
            
        
            [_pickTimeDiff selectRow:SpinHourRow inComponent:0 animated:false];
            [_pickTimeDiff selectRow:SpinMinRow inComponent:1  animated:false];
       
            
        }
        if( [body0 isEqual:@"MSG"] ) {
            NSString* body1 = [[words objectAtIndex:1] stringByAppendingString: @"\n" ];
            [self TextLoging:body1];
        }
        if( [body0 isEqual:@"CID"] ) {
            NSString* body1 = [[words objectAtIndex:1] stringByAppendingString: @"\n" ];
            _lblDeviceID.text = body1;
        }
        strSplit1 =@"";
    }
 
}


@end
