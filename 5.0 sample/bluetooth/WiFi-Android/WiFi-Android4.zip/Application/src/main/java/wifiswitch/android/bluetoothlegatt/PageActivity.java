/*
* Copyright 2013 The Android Open Source Project
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*     http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/


package wifiswitch.android.bluetoothlegatt;

import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattService;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;
import android.support.v4.app.FragmentTransaction;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.ViewAnimator;
import android.app.AlertDialog;
import android.content.DialogInterface;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.UUID;
import java.util.TimeZone;

import wifiswitch.android.common.activities.SampleActivityBase;
import wifiswitch.android.common.logger.Log;
import wifiswitch.android.common.logger.LogFragment;
import wifiswitch.android.common.logger.LogWrapper;
import wifiswitch.android.common.logger.MessageOnlyLogFilter;

/**
 * A simple launcher activity containing a summary sample description, sample log and a custom
 * {@link android.support.v4.app.Fragment} which can display a view.
 * <p>
 * For devices with displays with a width of 720dp or greater, the sample log is always visible,
 * on other devices it's visibility is controlled by an item on the Action Bar.
 */
public class PageActivity extends SampleActivityBase {

    public static final String TAG = "PageActivity";
    public static final String EXTRAS_DEVICE_NAME = "DEVICE_NAME";
    public static final String EXTRAS_DEVICE_ADDRESS = "DEVICE_ADDRESS";

    private TextView  mConnectionState;
    private Button btnRecv;
    private Button btnSend;
    private Button btnGet;
    private Button btnPut;

    // Whether the Log Fragment is currently shown
    private boolean mLogShown;
    private String mDeviceName;
    private String mDeviceAddress;

    // WiFi
    private EditText txtSID;
    private EditText txtPWD;
    private EditText txtOPIN;
    private EditText txtNPIN;
    private EditText txtIPA;
    // MQTT
    private EditText txtServer;
    private EditText txtPort;
    private EditText txtUserID;
    private EditText txtPassword;
    private EditText txtWillTopic;
    private Spinner  spnWillQoS;
    private Switch   swtWillRetain;
    private EditText txtWillMessage;

    private static String s1 = "", s2 = "";

    private BluetoothLeService mBluetoothLeService;
    private boolean mConnected = false;
    private BluetoothGattCharacteristic characteristicTX;
    private BluetoothGattCharacteristic characteristicRX;


    public final static UUID HM_RX_TX =
            UUID.fromString(SampleGattAttributes.HM_RX_TX);

    private final String LIST_NAME = "NAME";
    private final String LIST_UUID = "UUID";
    // Code to manage Service lifecycle.
    private final ServiceConnection mServiceConnection = new ServiceConnection() {

        @Override
        public void onServiceConnected(ComponentName componentName, IBinder service) {
            mBluetoothLeService = ((BluetoothLeService.LocalBinder) service).getService();
            if (!mBluetoothLeService.initialize()) {
                android.util.Log.e(TAG, "Unable to initialize Bluetooth");
                finish();
            }
            // Automatically connects to the device upon successful start-up initialization.
            mBluetoothLeService.connect(mDeviceAddress);
        }

        @Override
        public void onServiceDisconnected(ComponentName componentName) {
            mBluetoothLeService = null;
        }
    };

    // Handles various events fired by the Service.
    // ACTION_GATT_CONNECTED: connected to a GATT server.
    // ACTION_GATT_DISCONNECTED: disconnected from a GATT server.
    // ACTION_GATT_SERVICES_DISCOVERED: discovered GATT services.
    // ACTION_DATA_AVAILABLE: received data from the device.  This can be a result of read
    //                        or notification operations.
    private final BroadcastReceiver mGattUpdateReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            final String action = intent.getAction();
            if (BluetoothLeService.ACTION_GATT_CONNECTED.equals(action)) {
                mConnected = true;
                updateConnectionState(R.string.connected);
                invalidateOptionsMenu();
            } else if (BluetoothLeService.ACTION_GATT_DISCONNECTED.equals(action)) {
                mConnected = false;
                updateConnectionState(R.string.disconnected);
                invalidateOptionsMenu();
                clearUI();
            } else if (BluetoothLeService.ACTION_GATT_SERVICES_DISCOVERED.equals(action)) {
                // Show all the supported services and characteristics on the user interface.
                displayGattServices(mBluetoothLeService.getSupportedGattServices());
            } else if (BluetoothLeService.ACTION_DATA_AVAILABLE.equals(action)) {
                displayData(intent.getStringExtra(mBluetoothLeService.EXTRA_DATA));
            }
        }
    };

    private void clearUI() {

        //mDataField.setText(R.string.no_data);

    }

    private void updateConnectionState(final int resourceId) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                mConnectionState.setText(resourceId);
            }
        });
    }

    private void displayData(String data) {
        if (data != null) {
            //txtSID.setText(data);

            //Log.i(TAG, "Recv=" + data);

            String[] parts = data.split("\n");

            //Log.i(TAG, "Leng=" + parts.length);

            if (parts.length == 1) {
                if (parts[0].length() > 0) {
                    s1 = s1 + parts[0];
                    s2 = "";
                }
                /*else {
                    s1 = s1 + parts[0];
                }*/
            }
            //Log.d(TAG, "Str=" + s1 );

            if (parts.length == 2) {
                if (parts[1].length() > 0) {
                    s1 = s1 + parts[0];
                    s2 = "";
                } else {
                    s1 = s1 + parts[0];
                    s2 = parts[1];
                }
            }
            if ( data.endsWith("\n") ) {

                String[] cmds = s1.split("\t");
                //android.util.Log.d(TAG, "finish + " + cmds[0]);

                if (cmds[0].equals("ANS") ) {
                    txtIPA.setText(cmds[1]);
                    txtSID.setText(cmds[2]);
                    txtPWD.setText(cmds[3]);
                }
                if (cmds[0].equals("ENQ") ) {
                    txtServer.setText(cmds[1]);
                    txtPort.setText(cmds[2]);
                    txtUserID.setText(cmds[3]);
                    txtPassword.setText(cmds[4]);
                    txtWillTopic.setText(cmds[5]);

                    spnWillQoS.setSelection( Integer.parseInt (cmds[6]) - 1 );

                    if( cmds[7].equals("0") )
                        swtWillRetain.setChecked(false);
                    else
                        swtWillRetain.setChecked(true);

                    txtWillMessage.setText(cmds[8]);

                }

                if (cmds[0].equals("MSG")) {
                    Log.i(TAG, cmds[1]);
                }
                //  mDataField.setText(data);

                s1 = "";
            }
        }

    }

        // Demonstrates how to iterate through the supported GATT Services/Characteristics.
    // In this sample, we populate the data structure that is bound to the ExpandableListView
    // on the UI.
    private void displayGattServices(List<BluetoothGattService> gattServices) {
        if (gattServices == null) return;
        String uuid = null;
        String unknownServiceString = getResources().getString(R.string.unknown_service);
        ArrayList<HashMap<String, String>> gattServiceData = new ArrayList<HashMap<String, String>>();


        // Loops through available GATT Services.
        for (BluetoothGattService gattService : gattServices) {
            HashMap<String, String> currentServiceData = new HashMap<String, String>();
            uuid = gattService.getUuid().toString();
            currentServiceData.put(
                    LIST_NAME, SampleGattAttributes.lookup(uuid, unknownServiceString));

            // If the service exists for HM 10 Serial, say so.
            if(SampleGattAttributes.lookup(uuid, unknownServiceString) == "HM 10 Serial") {
                //    isSerial.setText("Yes, serial :-)");
            } else {
                //    isSerial.setText("No, serial :-(");
            }
            currentServiceData.put(LIST_UUID, uuid);
            gattServiceData.add(currentServiceData);

            // get characteristic when UUID matches RX/TX UUID
            characteristicTX = gattService.getCharacteristic(BluetoothLeService.UUID_HM_RX_TX);
            characteristicRX = gattService.getCharacteristic(BluetoothLeService.UUID_HM_RX_TX);
        }

    }

    private static IntentFilter makeGattUpdateIntentFilter() {
        final IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(BluetoothLeService.ACTION_GATT_CONNECTED);
        intentFilter.addAction(BluetoothLeService.ACTION_GATT_DISCONNECTED);
        intentFilter.addAction(BluetoothLeService.ACTION_GATT_SERVICES_DISCOVERED);
        intentFilter.addAction(BluetoothLeService.ACTION_DATA_AVAILABLE);
        return intentFilter;
    }

    private void btnListener( ) {

        btnSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {

                TimeZone tz = TimeZone.getDefault();
                String gmt1=TimeZone.getTimeZone(tz.getID()).getDisplayName(false, tz.SHORT);
                String gmt2=TimeZone.getTimeZone(tz.getID()).getDisplayName(false ,tz.LONG);
                //Log.i(TAG,"TimeZone : "+gmt1+"\t"+gmt2);

                String  chkStr = "P" + txtNPIN.getText();

                if( chkStr.equals("P") ) {
                    AlertDisplay("Please enter 4 digit pin number!");
                    return;
                }

                String  str = "@PUT\t"+ txtOPIN.getText() +"\t" + txtSID.getText()+"\t" + txtPWD.getText()+"\t" + txtNPIN.getText()+"\t" + gmt1 + "\n"; // PUT , SET
                //android.util.Log.d(TAG, "Sending result=" + str);
                Log.i(TAG, "Wait a monet, please!");

                final byte[] tx = str.getBytes();
                if(mConnected) {
                    characteristicTX.setValue(tx);
                    mBluetoothLeService.writeCharacteristic(characteristicTX);
                    mBluetoothLeService.setCharacteristicNotification(characteristicRX,true);
                }
            }
        });

        btnRecv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                String str = "@GET\t"+ txtOPIN.getText() +"\n"; //
                android.util.Log.d(TAG, "Sending result=" + str);

                final byte[] tx = str.getBytes();
                if(mConnected) {
                    characteristicTX.setValue(tx);
                    mBluetoothLeService.writeCharacteristic(characteristicTX);
                    mBluetoothLeService.setCharacteristicNotification(characteristicRX,true);
                }

            }
        });

        btnGet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                String str = "@LET\t1234\n"; // "LET"
                android.util.Log.d(TAG, "Sending result=" + str);

                final byte[] tx = str.getBytes();
                if(mConnected) {
                    characteristicTX.setValue(tx);
                    mBluetoothLeService.writeCharacteristic(characteristicTX);
                    mBluetoothLeService.setCharacteristicNotification(characteristicRX,true);
                }

            }
        });

        btnPut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {

                String str = "@SET\t1234\t"+txtServer.getText()+"\t"+txtPort.getText()+"\t"+txtUserID.getText()+"\t"+ txtPassword.getText()+"\t"+txtWillTopic.getText()+"\t"+ txtWillMessage.getText()+"\t"+spnWillQoS.getSelectedItem().toString()+"\t"+( swtWillRetain.isChecked() ? 1: 0 )+"\t\n";
                //android.util.Log.d(TAG, "Sending result=" + str);
                Log.i(TAG, "Wait a monet, please!"+txtWillMessage.getText());

                final byte[] tx = str.getBytes();

                if(mConnected) {
                    characteristicTX.setValue(tx);
                    mBluetoothLeService.writeCharacteristic(characteristicTX);
                    mBluetoothLeService.setCharacteristicNotification(characteristicRX,true);
                }

            }
        });

    }

    private void AlertDisplay(String Message)
    {

        AlertDialog.Builder builder1 = new AlertDialog.Builder(this);
        builder1.setMessage(Message);
        builder1.setCancelable(true);

        builder1.setPositiveButton(
                "OK",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                    }
                });

        /*
        builder1.setNegativeButton(
                "No",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                    }
                });
        */
        AlertDialog alert11 = builder1.create();
        alert11.show();
    }

    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final Intent intent = getIntent();
        mDeviceName = intent.getStringExtra(EXTRAS_DEVICE_NAME);
        mDeviceAddress = intent.getStringExtra(EXTRAS_DEVICE_ADDRESS);

        if (savedInstanceState == null) {
            FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
            SlidingTabsBasicFragment fragment = new SlidingTabsBasicFragment();
            transaction.replace(R.id.sample_content_fragment, fragment);
            transaction.commit();
        }

       // Sets up UI references.
       // ((TextView) findViewById(R.id.device_address)).setText(mDeviceAddress);

        mConnectionState = (TextView) findViewById(R.id.s_connection_state);

        getActionBar().setTitle(mDeviceName);
        getActionBar().setDisplayHomeAsUpEnabled(true);
    }

    @Override
    protected void onResume() {
        super.onResume();
        registerReceiver(mGattUpdateReceiver, makeGattUpdateIntentFilter());
        if (mBluetoothLeService != null) {
            final boolean result = mBluetoothLeService.connect(mDeviceAddress);
            android.util.Log.d(TAG, "Connect request result=" + result);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        unregisterReceiver(mGattUpdateReceiver);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        unbindService(mServiceConnection);
        mBluetoothLeService = null;
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.gatt_services, menu);
        if (mConnected) {
            menu.findItem(R.id.menu_connect).setVisible(false);
            menu.findItem(R.id.menu_disconnect).setVisible(true);
        } else {
            menu.findItem(R.id.menu_connect).setVisible(true);
            menu.findItem(R.id.menu_disconnect).setVisible(false);
        }

        Intent gattServiceIntent = new Intent(this, BluetoothLeService.class);
        bindService(gattServiceIntent, mServiceConnection, BIND_AUTO_CREATE);

        btnRecv = (Button) findViewById(R.id.Recv);
        btnSend = (Button) findViewById(R.id.Send);

        btnGet = (Button) findViewById(R.id.Get);
        btnPut = (Button) findViewById(R.id.Put);

        btnListener();

        txtSID = (EditText) findViewById(R.id.s_editSID);
        txtPWD = (EditText) findViewById(R.id.s_editPWD);
        txtOPIN = (EditText) findViewById(R.id.s_editOPIN);
        txtNPIN = (EditText) findViewById(R.id.s_editNPIN);
        txtIPA = (EditText) findViewById(R.id.s_editIPA);
        txtServer = (EditText) findViewById(R.id.s_editServer);
        txtPort = (EditText) findViewById(R.id.s_editPort);
        txtUserID = (EditText) findViewById(R.id.s_editUserID);
        txtPassword = (EditText) findViewById(R.id.s_editPassword);
        txtWillTopic = (EditText) findViewById(R.id.s_editWillTopic);
        spnWillQoS = (Spinner) findViewById(R.id.spinnerWillQoS);
        swtWillRetain= (Switch) findViewById(R.id.switchWillRetain);
        txtWillMessage = (EditText) findViewById(R.id.s_editWillMessage);

        ViewAnimator output = (ViewAnimator) findViewById(R.id.sample_output);
        output.setDisplayedChild(1);

        return true;
    }

    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
       // MenuItem logToggle = menu.findItem(R.id.menu_toggle_log);
        //logToggle.setVisible(findViewById(R.id.sample_output) instanceof ViewAnimator);
        //logToggle.setTitle(mLogShown ? R.string.sample_hide_log : R.string.sample_show_log);

        return super.onPrepareOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch(item.getItemId()) {
            case R.id.menu_connect:
                mBluetoothLeService.connect(mDeviceAddress);
                return true;
            case R.id.menu_disconnect:
                mBluetoothLeService.disconnect();
                return true;
            case android.R.id.home:
                onBackPressed();
                return true;
        }

        /*
        switch(item.getItemId()) {
            case R.id.menu_toggle_log:
                mLogShown = !mLogShown;
                ViewAnimator output = (ViewAnimator) findViewById(R.id.sample_output);
                if (mLogShown) {
                    output.setDisplayedChild(1);
                } else {
                    output.setDisplayedChild(0);
                }
                supportInvalidateOptionsMenu();
                return true;
        } */
        //ViewAnimator output = (ViewAnimator) findViewById(R.id.sample_output);
        //output.setDisplayedChild(1);

        return super.onOptionsItemSelected(item);
    }

    /** Create a chain of targets that will receive log data */
    @Override
    public void initializeLogging() {
        // Wraps Android's native log framework.
        LogWrapper logWrapper = new LogWrapper();
        // Using Log, front-end to the logging chain, emulates android.util.log method signatures.
        Log.setLogNode(logWrapper);

        // Filter strips out everything except the message text.
        MessageOnlyLogFilter msgFilter = new MessageOnlyLogFilter();
        logWrapper.setNext(msgFilter);

        // On screen logging via a fragment with a TextView.
        LogFragment logFragment = (LogFragment) getSupportFragmentManager()
                .findFragmentById(R.id.log_fragment);
        msgFilter.setNext(logFragment.getLogView());

        Log.i(TAG, "Ready");


    }
}
