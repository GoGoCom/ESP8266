/*
 * Copyright (C) 2013 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package wifiswitch.android.bluetoothlegatt;

import android.app.Activity;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattService;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.UUID;

import android.widget.SeekBar;

/**
 * For a given BLE device, this Activity provides the user interface to connect, display data,
 * and display GATT services and characteristics supported by the device.  The Activity
 * communicates with {@code BluetoothLeService}, which in turn interacts with the
 * Bluetooth LE API.
 */
public class DeviceControlActivity extends Activity {
    // BLE
    private final static String TAG = DeviceControlActivity.class.getSimpleName();

    public static final String EXTRAS_DEVICE_NAME = "DEVICE_NAME";
    public static final String EXTRAS_DEVICE_ADDRESS = "DEVICE_ADDRESS";

    private TextView  mConnectionState;

    // WiFi
    private EditText txtSID;
    private EditText txtPWD;
    private EditText txtOPIN;
    private EditText txtNPIN;
    private EditText txtIPA;
    // MQTT
    private EditText txtServer;
    private EditText txtPort;
    private EditText txtUserID;
    private EditText txtPassword;
    private EditText txtWillTopic;
    private EditText txtWillQoS;
    private EditText txtWillRetain;
    private EditText txtWillMessage;

    private static String s1 = "", s2 = "";

    private String mDeviceName;
    private String mDeviceAddress;

    private Button btnStart;
    private Button btnStop;

    //  private ExpandableListView mGattServicesList;
    private BluetoothLeService mBluetoothLeService;
    private boolean mConnected = false;
    private BluetoothGattCharacteristic characteristicTX;
    private BluetoothGattCharacteristic characteristicRX;


    public final static UUID HM_RX_TX =
            UUID.fromString(SampleGattAttributes.HM_RX_TX);

    private final String LIST_NAME = "NAME";
    private final String LIST_UUID = "UUID";

    // Code to manage Service lifecycle.
    private final ServiceConnection mServiceConnection = new ServiceConnection() {

        @Override
        public void onServiceConnected(ComponentName componentName, IBinder service) {
            mBluetoothLeService = ((BluetoothLeService.LocalBinder) service).getService();
            if (!mBluetoothLeService.initialize()) {
                Log.e(TAG, "Unable to initialize Bluetooth");
                finish();
            }
            // Automatically connects to the device upon successful start-up initialization.
            mBluetoothLeService.connect(mDeviceAddress);
        }

        @Override
        public void onServiceDisconnected(ComponentName componentName) {
            mBluetoothLeService = null;
        }
    };

    // Handles various events fired by the Service.
    // ACTION_GATT_CONNECTED: connected to a GATT server.
    // ACTION_GATT_DISCONNECTED: disconnected from a GATT server.
    // ACTION_GATT_SERVICES_DISCOVERED: discovered GATT services.
    // ACTION_DATA_AVAILABLE: received data from the device.  This can be a result of read
    //                        or notification operations.
    private final BroadcastReceiver mGattUpdateReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            final String action = intent.getAction();
            if (BluetoothLeService.ACTION_GATT_CONNECTED.equals(action)) {
                mConnected = true;
                updateConnectionState(R.string.connected);
                invalidateOptionsMenu();
            } else if (BluetoothLeService.ACTION_GATT_DISCONNECTED.equals(action)) {
                mConnected = false;
                updateConnectionState(R.string.disconnected);
                invalidateOptionsMenu();
                clearUI();
            } else if (BluetoothLeService.ACTION_GATT_SERVICES_DISCOVERED.equals(action)) {
                // Show all the supported services and characteristics on the user interface.
                displayGattServices(mBluetoothLeService.getSupportedGattServices());
            } else if (BluetoothLeService.ACTION_DATA_AVAILABLE.equals(action)) {
                displayData(intent.getStringExtra(mBluetoothLeService.EXTRA_DATA));
            }
        }
    };

    private void clearUI() {

        //mDataField.setText(R.string.no_data);

    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.gatt_services_characteristics);

        final Intent intent = getIntent();
        mDeviceName = intent.getStringExtra(EXTRAS_DEVICE_NAME);
        mDeviceAddress = intent.getStringExtra(EXTRAS_DEVICE_ADDRESS);

        // Sets up UI references.
        ((TextView) findViewById(R.id.device_address)).setText(mDeviceAddress);
        mConnectionState = (TextView) findViewById(R.id.connection_state);

        // is serial present?
        txtSID = (EditText) findViewById(R.id.editSID);
        txtPWD = (EditText) findViewById(R.id.editPWD);
        txtOPIN = (EditText) findViewById(R.id.editOPIN);
        txtNPIN = (EditText) findViewById(R.id.editNPIN);
        txtIPA = (EditText) findViewById(R.id.editIPA);
        txtServer = (EditText) findViewById(R.id.editServer);
        txtPort = (EditText) findViewById(R.id.editPort);
        txtUserID = (EditText) findViewById(R.id.editUserID);
        txtPassword = (EditText) findViewById(R.id.editPassword);
        //txtWillTopic = (EditText) findViewById(R.id.editWillTopic);
        //txtWillQoS = (EditText) findViewById(R.id.editWillQoS);
        //txtWillRetain= (EditText) findViewById(R.id.editWillRetain);
        //txtWillMessage = (EditText) findViewById(R.id.editWillMessage);


        btnStart = (Button) findViewById(R.id.Run);
        btnStop = (Button) findViewById(R.id.Stop);

        readSeek( );

        getActionBar().setTitle(mDeviceName);
        getActionBar().setDisplayHomeAsUpEnabled(true);
        Intent gattServiceIntent = new Intent(this, BluetoothLeService.class);
        bindService(gattServiceIntent, mServiceConnection, BIND_AUTO_CREATE);
    }

    @Override
    protected void onResume() {
        super.onResume();
        registerReceiver(mGattUpdateReceiver, makeGattUpdateIntentFilter());
        if (mBluetoothLeService != null) {
            final boolean result = mBluetoothLeService.connect(mDeviceAddress);
            Log.d(TAG, "Connect request result=" + result);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        unregisterReceiver(mGattUpdateReceiver);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        unbindService(mServiceConnection);
        mBluetoothLeService = null;
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.gatt_services, menu);
        if (mConnected) {
            menu.findItem(R.id.menu_connect).setVisible(false);
            menu.findItem(R.id.menu_disconnect).setVisible(true);
        } else {
            menu.findItem(R.id.menu_connect).setVisible(true);
            menu.findItem(R.id.menu_disconnect).setVisible(false);
        }
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch(item.getItemId()) {
            case R.id.menu_connect:
                mBluetoothLeService.connect(mDeviceAddress);
                return true;
            case R.id.menu_disconnect:
                mBluetoothLeService.disconnect();
                return true;
            case android.R.id.home:
                onBackPressed();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void updateConnectionState(final int resourceId) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                mConnectionState.setText(resourceId);
            }
        });
    }

    private void displayData(String data) {

        if (data != null) {
            //txtSID.setText(data);

            Log.d(TAG, "Recv=" + data);

            String[] parts = data.split("\n");

            Log.d(TAG, "Leng=" + parts.length);

            if (parts.length == 1) {
                if (parts[0].length() > 0) {
                    s1 = s1 + parts[0];
                    s2 = "";
                }
                /*else {
                    s1 = s1 + parts[0];
                }*/
            }
           //Log.d(TAG, "Str=" + s1 );

            if (parts.length == 2) {
                if (parts[1].length() > 0) {
                    s1 = s1 + parts[0];
                    s2 = "";
                } else {
                    s1 = s1 + parts[0];
                    s2 = parts[1];
                }
            }
            if ( data.endsWith("\n") ) {

                String[] cmds = s1.split("\t");
                Log.d(TAG, "finish + " + cmds[0]);

                if (cmds[0].equals("ANS") ) {
                    txtIPA.setText(cmds[1]);
                    txtSID.setText(cmds[2]);
                    txtPWD.setText(cmds[3]);
                }
                if (cmds[0].equals("ENQ") ) {
                    txtServer.setText(cmds[1]);
                    txtPort.setText(cmds[2]);
                    txtUserID.setText(cmds[3]);
                    txtPassword.setText(cmds[4]);
                    //txtWillTopic.setText(cmds[5]);
                    //txtWillQoS.setText(cmds[6]);
                    //txtWillRetain.setText(cmds[7]);
                    //txtWillMessage.setText(cmds[8]);

                }

                if (cmds[0].equals("MSG")) {
                    Log.d(TAG, "msg=" + cmds[1]);
                }
                //  mDataField.setText(data);

                s1 = "";
            }
        }
    }


    // Demonstrates how to iterate through the supported GATT Services/Characteristics.
    // In this sample, we populate the data structure that is bound to the ExpandableListView
    // on the UI.
    private void displayGattServices(List<BluetoothGattService> gattServices) {
        if (gattServices == null) return;
        String uuid = null;
        String unknownServiceString = getResources().getString(R.string.unknown_service);
        ArrayList<HashMap<String, String>> gattServiceData = new ArrayList<HashMap<String, String>>();


        // Loops through available GATT Services.
        for (BluetoothGattService gattService : gattServices) {
            HashMap<String, String> currentServiceData = new HashMap<String, String>();
            uuid = gattService.getUuid().toString();
            currentServiceData.put(
                    LIST_NAME, SampleGattAttributes.lookup(uuid, unknownServiceString));

            // If the service exists for HM 10 Serial, say so.
            if(SampleGattAttributes.lookup(uuid, unknownServiceString) == "HM 10 Serial") {
            //    isSerial.setText("Yes, serial :-)");
            } else {
            //    isSerial.setText("No, serial :-(");
            }
            currentServiceData.put(LIST_UUID, uuid);
            gattServiceData.add(currentServiceData);

            // get characteristic when UUID matches RX/TX UUID
            characteristicTX = gattService.getCharacteristic(BluetoothLeService.UUID_HM_RX_TX);
            characteristicRX = gattService.getCharacteristic(BluetoothLeService.UUID_HM_RX_TX);
        }

    }

    private static IntentFilter makeGattUpdateIntentFilter() {
        final IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(BluetoothLeService.ACTION_GATT_CONNECTED);
        intentFilter.addAction(BluetoothLeService.ACTION_GATT_DISCONNECTED);
        intentFilter.addAction(BluetoothLeService.ACTION_GATT_SERVICES_DISCOVERED);
        intentFilter.addAction(BluetoothLeService.ACTION_DATA_AVAILABLE);
        return intentFilter;
    }

    private void readSeek( ) {

    //    private void readSeek  }(SeekBar seekBar,final int pos) {
        /*
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress,
                                          boolean fromUser) {
                RGBFrame[pos]=progress;
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                // TODO Auto-generated method stub
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                // TODO Auto-generated method stub
                makeChange();
            }
        });
      */

        btnStart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
              //  double speed = ( (float) RGBFrame[0] / 255f) * 14000;
              //  double time = ( (float) RGBFrame[1] / 255f ) * 300;

              //  int minute = (int) time / 60 ;
              //  int sec = (int) time - minute * 60;

                //String str = String.format("FT%1$02d%2$02d%3$05d\n", minute , sec, (int) speed );

//                oPIN = Serial.readStringUntil('\t');
//                tSID = Serial.readStringUntil('\t');
//                tPWD = Serial.readStringUntil('\t');
//                tPIN = Serial.readStringUntil('\t');
//                tZON = Serial.readStringUntil('\n');
//

                /*
                oPIN = Serial.readStringUntil('\t');
                mSVR = Serial.readStringUntil('\t');
                mPOT = Serial.readStringUntil('\t');
                mUSR = Serial.readStringUntil('\t');
                mPAS = Serial.readStringUntil('\t');
                mTPC = Serial.readStringUntil('\t');
                mQOS = Serial.readStringUntil('\t');
                mRET = Serial.readStringUntil('\t');
                mMES = Serial.readStringUntil('\n');
                */

                String  str = "FT"; // PUT , SET
                Log.d(TAG, "Sending result=" + str);

                final byte[] tx = str.getBytes();
                if(mConnected) {
                    characteristicTX.setValue(tx);
                    mBluetoothLeService.writeCharacteristic(characteristicTX);
                    mBluetoothLeService.setCharacteristicNotification(characteristicRX,true);
                }
            }
        });

        btnStop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                String str = "@GET\t1234\n"; // "LET"
                Log.d(TAG, "Sending result=" + str);

                final byte[] tx = str.getBytes();
                if(mConnected) {
                    characteristicTX.setValue(tx);
                    mBluetoothLeService.writeCharacteristic(characteristicTX);
                    mBluetoothLeService.setCharacteristicNotification(characteristicRX,true);
                }

            }
        });

    }

    // on change of bars write char
    private void makeChange() {
        /*
        String str = RGBFrame[0] + "," + RGBFrame[1] + "," + RGBFrame[2] + "\n";
        Log.d(TAG, "Sending result=" + str);
        double speed = ( (float) RGBFrame[0] / 255f) * 14000;

        String strSpeed = String.format("%1$5d RPM", (int) speed);

        txtSpeed.setText(strSpeed);

        double time = ( (float) RGBFrame[1] / 255f ) * 300;

        int minute = (int) time / 60 ;
        int sec = (int) time - minute * 60;

        String strTime = String.format("%1$02d Min %2$02d Sec", minute , sec );

        txtTime.setText(strTime);
        */

        /*
        final byte[] tx = str.getBytes();
        if(mConnected) {
            characteristicTX.setValue(tx);
            mBluetoothLeService.writeCharacteristic(characteristicTX);
            mBluetoothLeService.setCharacteristicNotification(characteristicRX,true);
        } */

    }





}